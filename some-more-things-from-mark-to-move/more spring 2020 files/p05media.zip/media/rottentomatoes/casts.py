from . import datasets as ds

def get_cast(*ids):
    """
    Accepts n movie ids and returns all of the cast members in a tuple.
    """
    cast = ds.movies.loc[ds.movies['rt_id'].isin(ids),'cast']
    if cast.empty:
        return ()
    else:
        # combines results into one giant comma separated string
        combined = ','.join([actor for actor in cast])
        return tuple(actor.strip() for actor in combined.split(","))


def cast_in_common(*ids):
    """
    Accepts n movie ids and returns a tuple containing every cast member found
    across all provided movies.
    """
    result = set.intersection(*tuple(set(get_cast(id)) for id in ids))
    return tuple(result)
