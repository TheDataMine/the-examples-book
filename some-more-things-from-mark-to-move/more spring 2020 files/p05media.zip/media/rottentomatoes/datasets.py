import pandas as pd

# by default load basic datasets when package is imported
movies = pd.read_pickle("./media/rottentomatoes/movies")
reviews = pd.read_pickle("./media/rottentomatoes/reviews")

# remove the '/m/' from the link
movies['rotten_tomatoes_link'] = movies['rotten_tomatoes_link'].str.replace('/m/', '')
reviews['rotten_tomatoes_link'] = reviews['rotten_tomatoes_link'].str.replace('/m/', '')

# change the column name
movies.rename(columns={'rotten_tomatoes_link': 'rt_id'}, inplace=True)
reviews.rename(columns={'rotten_tomatoes_link': 'rt_id'}, inplace=True)
