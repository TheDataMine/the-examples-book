from . import datasets as ds
import sys

def get_reviews(id: str, n: int):
    """
    Given a movie id, and a number n, returns a two lists. The first list
    contains n reviews of the movie with the provided
    id. The second contains the associated classification "Rotten" or 
    "Fresh" of each review in the first list.
    """
    try:
        sample = ds.reviews.loc[ds.reviews['review_content'].notna().multiply(ds.reviews['rt_id']==id)]
        # sample = sample.sample(n=n)
    except ValueError as e:
        num = ds.reviews.loc[ds.reviews['review_content'].notna().multiply(ds.reviews['rt_id']==id)].shape[0]
        sys.exit(f"There are only {num} reviews for the movie with rotten tomatoes id {id}.")
    except:
        sys.exit(f"Rotten tomatoes id '{id}' not found.")

    reviews = sample.loc[ds.reviews['rt_id']==id, 'review_content']
    classifications = sample.loc[ds.reviews['rt_id']==id, 'critic_icon']
    
    if reviews.empty:
        return ()
    else:
        return reviews.to_list(), classifications.to_list()
