from typing import Tuple
from math import log
import numpy as np
import string
from stop_words import get_stop_words

from . import datasets as ds


def search(*words):
    """
    Return dataframe where all of the provided words 
    are found in the movie title in the pre-loaded movies 
    dataset. Case insensitive.
    """
    return ds.movies[np.logical_and.reduce([ds.movies['movie_title'].str.contains(word, case=False) for word in words])]


def corpus_terms(corpus: Tuple[str, ...]):
    return list(set(parse_doc(' '.join(tuple(document for document in corpus)))))


def parse_doc(document: str):
    document = document.lower()
    stop_words = get_stop_words('english')
    return [word for word in document.translate(document.maketrans('', '', string.punctuation)).split() if word not in stop_words]


def idf(corpus: Tuple[str, ...], terms: Tuple[str, ...], smooth: bool = True):
    
    def _dt(corpus: Tuple[str, ...], term: str):
        """
        Helper function that returns the number of documents
        in the provided corpus where the term appears.
        """
        return sum(tuple(term.lower() in parse_doc(document) for document in corpus))
    
    if smooth:
        return [log((1+len(corpus))/(1+_dt(corpus, term))) for term in terms]
    
    return [log(len(corpus)/_dt(corpus, term)) for term in terms]


def tf(document: str, terms: Tuple[str, ...]):
    return [parse_doc(document).count(term.lower()) for term in terms]


def tfidf(corpus: Tuple[str, ...], terms: Tuple[str, ...]):
    result = []
    term_idfs = idf(corpus, terms)
    for idx, document in enumerate(corpus):
        result.append([tf*idf for tf, idf in zip(tf(document, terms), term_idfs)])

    return result