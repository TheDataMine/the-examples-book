from . import datasets as ds

def get_polarizing():
    """
    Return all movies where there are > 20 `tomatometer_count` and `tomatometer_rating`
    and `audience_rating` differ by >= 20.
    """
    return ds.movies[(ds.movies['tomatometer_count']>20) & (abs(ds.movies['tomatometer_rating'] - ds.movies['audience_rating']) >= 20)]
