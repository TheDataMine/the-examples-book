import pandas as pd

# by default load basic datasets when package is imported
movies = pd.read_pickle("./media/rottentomatoes/movies")
reviews = pd.read_pickle("./media/rottentomatoes/reviews")
