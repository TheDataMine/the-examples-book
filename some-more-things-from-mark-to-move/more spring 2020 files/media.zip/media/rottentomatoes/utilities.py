import numpy as np

from . import datasets as ds

def search(*words):
    """
    Return dataframe where all of the provided words 
    are found in the movie title in the pre-loaded movies 
    dataset. Case insensitive.
    """
    return ds.movies[np.logical_and.reduce([ds.movies['movie_title'].str.contains(word, case=False) for word in words])]