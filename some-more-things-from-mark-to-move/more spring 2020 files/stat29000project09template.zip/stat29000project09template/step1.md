## Signing up

In this initial step, a user creates an account by entering, among other things, a username and a password.

In this example, our user info is minimal and only includes a username and password.