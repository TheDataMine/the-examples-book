# Overview

This is an interactive demo built with `shiny` in order to help users understand some of the concepts involved in authenticating a user using a username and password.

Users can go step by step using either the tabs or the next buttons. This demo will walk through the following steps:

1. Signing up
2. Hashing
3. Salting
4. Storing
5. Logging in

The following packages make this demonstration possible:

- `shiny`
- `DT`
- `markdown`
- `openssl`
- `bcrypt`
- `data.table`
- `DiagrammeR`

The following code chunk will install any missing packages:

```r
install.packages("shiny")
install.packages("DT")
install.packages("markdown")
install.packages("openssl")
install.packages("bcrypt")
install.packages("data.table")
install.packages("DiagrammeR")
```