## Logging in

In addition to the usernames and passwords you may or may not have added in step (4), a list of usernames and passwords can be found in the provided `utils.R` file. Try to "log in" using a correct username and password combination, and an incorrect username and password combination. The app will display "Success!" or "Failure!" depending on whether the "log in" was a success or not.