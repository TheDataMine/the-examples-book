## See it in action

"Sign up" with a username and password, and see the entry get added to the database.