## Salting

In step (2) we made a note that `sha256` isn't cryptographically secure. The reason is that specialized hardware can be taken advantage of to speed up the computation of a `sha256` hash. This allows a malicious party to create [rainbow tables](https://en.wikipedia.org/wiki/Rainbow_table) quickly. If a malicious party had access to a database with hashed passwords, they may be able to create a rainbow table. This allows them to identify weak passwords when matching hashes are found in the rainbow table.

One way to make this less feasible for the malicious party is called salting. A salt is just a string of random characters generated using a cryptographically secure pseudo-random number generator. 

Prior to putting the password through the hash function, a salt is generated and appended to the password. This ensures that two users with the same passwords will have different hashes. It also means the malicious party would have to create rainbow tables for each user rather than one rainbow table for the whole database.

Often times, after the password is "salted" and hashed, the salt is prepended to the hash for easy access.