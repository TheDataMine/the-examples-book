library("bcrypt")
library("openssl")
library("data.table")


usernames <- c("john", "jane", "jean", "sean", "mark", "ziva", "edgar", "max", "arnold", "cindy")
original_passwords <- c("apple", "banana", "orange", "apple", "superman", "brick", "turtle", "datamine", "ninenine", "password")

# a function that salts and hashes a password
hash_password <- function(password, salt = gensalt()) {
    # call salt_password
}

# a function that salts a password
salt_password <- function(password, salt = gensalt()) {

}

# a function that checks to see if a password matches the salted hash in the database
check_password <- function(password, salted_hash) {

}

# a data.table that represents a database table to store user info
hashed_passwords <- unlist(lapply(original_passwords, hash_password))
userDB <- data.table(usernames=usernames, passwords=hashed_passwords)
