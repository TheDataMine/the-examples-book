## Hashing

A hash function takes an input and maps it to an output of known length. The same input will result in the exact same result, or hash. Any change in the input, will result in a completely different hash. Reversing a hash function can usually not be done, i.e. given a hash, you will not be able to "calculate" the original input.

If you were to hash two different inputs and the resulting hashes were the same, this would be called a collision. `sha256` is an algorithm that maps any input to a 256 bit hash (64 characters long). To this day there has not been a discovered collision using `sha256`.

Test out the `sha256` function from the `openssl` package in R to get a better feel for it.

**Note:** *Although `sha256` has no known collisions, it is not cryptographically secure. Due to the way the algorithm is written, specialized hardware like GPU's can be used to compute hashes extremely fast, which leads to security issues. Regardless, it works perfectly fine for demonstration purposes.* 

```r
library(openssl)


sha256("a")
sha256("thequickbrownfox")
# even slightly changing the input will result in 
# completely different output
sha256("thequickbrownfoxx") 
sha256("thequickbrownfoxjumpedoverthelazydogs")

# the output is always 64 characters or 256 bits in length
nchar(sha256("a"))
nchar(sha256("thequickbrownfox"))
nchar(sha256("thequickbrownfoxx"))
nchar(sha256("thequickbrownfoxjumpedoverthelazydogs"))
```