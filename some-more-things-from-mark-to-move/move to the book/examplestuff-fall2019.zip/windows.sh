#!/bin/bash
PATH=/apps/cent7/qemu/2.10.1/bin:$PATH
/apps/cent7/qemu/2.10.1/bin/windows -i /scratch/scholar/$1/windows-base.qcow2 -c 2 -m 16G -s /class/datamine
