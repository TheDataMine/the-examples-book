# Regular expressions enable us to identify strings that match certain patterns.
# We give several examples to illustrate regular expressions.

myDF <- read.delim("/class/datamine/data/election/itcont2020.txt", sep="|")

# There are 277636 donations from cities that contain the word "TON"
length(grep("TON",myDF$CITY,value=T))

# Only 278 of the donations are from cities that start with the word "TON"
length(grep("^TON",myDF$CITY,value=T))

# Those cities are:
table(grep("^TON",myDF$CITY,value=T))

# There are 10 distinct city names that start with "TON":
length(table(grep("^TON",myDF$CITY,value=T)))

# and 235188 of the donations are from cities that end with the word "TON"
length(grep("TON$",myDF$CITY,value=T))

# A long description of regular expressions are given here:
?regex

# The cheat sheet from RStudio is a convenient summary of regular expressions:
# https://rstudio.com/wp-content/uploads/2016/09/RegExCheatsheet.pdf

# The examples given above are called "anchors":
#   Having a ^ that (must) match at the start of the string
#   or having a $ that (must) match at the end of the string

# We can also specify that a pattern needs to be repeated.
# These are given in the quantifiers section of the cheat sheet.

# For instance, 243 of the donations are from cities that
# have 2 (or more) consecutive occurrences of AN
length(grep("(AN){2}",myDF$CITY,value=T))

# Those cities are:
table(grep("(AN){2}",myDF$CITY,value=T))

# Only 1489 of the donations are from cities that start with the phrase "T.N"
# where the "." can be any character.
length(grep("^T.N",myDF$CITY,value=T))

# These cities are:
table(grep("^T.N",myDF$CITY,value=T))

# Only 5761 of the donations are from cities that end with either Q or Z
length(grep("[QZ]$",myDF$CITY,value=T))

# These cities are:
table(grep("[QZ]$",myDF$CITY,value=T))

# This pattern [QZ] is an example of a character class.# There are 61936 cities that start with
# either the pattern IN or the pattern CO
length(grep("^(IN|CO)",myDF$CITY,value=T))

# These are the following cities:
table(grep("^(IN|CO)",myDF$CITY,value=T))

# Such patterns are sometimes called alternations.

# We can also see that 1375568 of the cities start with a letter from A to M
length(grep("^[A-M]",myDF$CITY,value=T))

# and 1093710 of the cities start with a letter from N to Z
length(grep("^[N-Z]",myDF$CITY,value=T))

# There are 5266 cities that have
# C followed by 0 or more occurrences of OR followed by D
length(grep("C(OR)*D",myDF$CITY,value=T))

# these are:
table(grep("C(OR)*D",myDF$CITY,value=T))

# There are 4921 cities that have
# C followed by 1 or more occurrences of OR followed by D
length(grep("C(OR)+D",myDF$CITY,value=T))

# these are:
table(grep("C(OR)+D",myDF$CITY,value=T))

# The only cities in the first list who are not in the second list are:
# CDA     FORT MCDOWELL     MCDONALD     MCDONOUGH

# The symbols (* and +) are called quantifiers.

