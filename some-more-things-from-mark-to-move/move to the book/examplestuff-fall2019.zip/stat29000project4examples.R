# Suppose that we want to know how much money is spent on food products, non-food products, and pharma products.

# We import the data about the 84.51 transactions:
myDF <- read.csv("/class/datamine/data/8451/The_Complete_Journey_2_Master/5000_transactions.csv")
names(myDF)

# The transactions table does not have any information about
# what kind of items that the products are.

# Instead, we can get some information about the products from this data frame:
myproductDF <- read.csv("/class/datamine/data/8451/The_Complete_Journey_2_Master/5000_products.csv")
head(myproductDF)

# There are 3 kinds of products: food, non-food, and pharma.
table(myproductDF$DEPARTMENT)
# This data set has extra spaces in the names of these products:
names(table(myproductDF$DEPARTMENT))
# We can clean this up, as follows:
myproductDF$DEPARTMENT <- trimws(myproductDF$DEPARTMENT)
# Now the types of products look cleaner:
names(table(myproductDF$DEPARTMENT))

# We can make a vector called "myproducttype" that stores the types of each product:
myproducttype <- myproductDF$DEPARTMENT
# and we use the products themselves as the names of this vector:
names(myproducttype) <- myproductDF$PRODUCT_NUM

# Then we can use this vector to lookup the product type (from the names of the vector),
# for any product number (which is the actual data in the vector).

# For instance, product number 94594 has type "non-food":
myproducttype["94594"]

# The first six transactions are:
head(myDF)

# so the first six product numbers are:
head(myDF)$PRODUCT_NUM

# It turns out that all six of the products purchased in those transactions are of type "food":
myproducttype[c("5817389", "5829886", "539501", "5260099", "4535660", "5602916")]

# but if we try to do this more seamlessly, we run into difficulty:
myproducttype[head(myDF)$PRODUCT_NUM]

# The challenge is that these are integers,
# but myproducttype expects to have character inputs.
myproducttype[as.character(head(myDF)$PRODUCT_NUM)]

# So now that we carefully checked this,
# we can remove the head and find the product type of every product in the transactions data frame.
# This will be a lot of output (10 million entries) so you might not want to see it all:
myproducttype[as.character(myDF$PRODUCT_NUM)]

# It makes more sense to just make a table of these results,
# so that we can see how many transactions of each type occurred.
table(myproducttype[as.character(myDF$PRODUCT_NUM)])

# Here is another way to write this concept, which is basically the same,
# but it might be easier to read.

# We can start by making a character vector of the product numbers from the data frame,
# insisting that these are character types
v <- as.character(myDF$PRODUCT_NUM)

# Notice that v has the same length as the number of rows in the data frame itself:
length(v)
dim(myDF)

# We can ask for the producttype of each element of v, as we did before:
myproducttype[head(v)]

# and we can get the same results as before:
table(myproducttype[v])

# If this seems challenging, please note that we did NOT do this all in one step.

# We worked carefully, and we checked our results as we worked, and we frequently checked
# the head, the type of data, the length or dimension, etc.

# These are important skills to develop, and they take a little time,
# but we can work things out on paper, and try some examples, and make sure that things work
# on small examples, before moving to full examples.


