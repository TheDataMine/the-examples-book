#!/bin/bash
cp /scratch/scholar/$1/trythis.txt /scratch/scholar/$1/done.txt
