# The tapply function works as follows:

#     tapply(the data to work on,
#            the way that the data is organized,
#            a function to run on each piece of data)

# The data to work on, and the way that the data is organized, must always be the same length.
# We can think of this as splitting the data (from the first data set) into groups,
# based on the data from the second data set.
# Then we apply the function to the first data set, group by group.

# Examples using the tapply function for questions about the grocery store transactions

myDF <- read.csv("/class/datamine/data/8451/The_Complete_Journey_2_Master/5000_transactions.csv")

# There are actually some extra spaces in the STORE_R column, as you can see here:
head(as.character(myDF$STORE_R))
# Let's clean up those extra spaces first:
myDF$STORE_R <- trimws(myDF$STORE_R)
# You will probably not need to do that with the other data sets in this project,
# but doing clean up is part of data analysis.
# Things look better now:
head(as.character(myDF$STORE_R))

###### How much money was spent at the East store altogether? ######

# The amount of money spent is in the SPEND column.
# The stores are in the STORE_R column.
# We want to add up the money, using the sum command.

tapply(myDF$SPEND, myDF$STORE_R, sum)

# So 11699447 dollars were spent at the East store altogether.

# Another method -- just to double check our work -- is to look at *only* the
# elements of the SPEND column for which the STORE_R column is equal to EAST.
sum(myDF$SPEND[myDF$STORE_R == "EAST"])

###### On which day was the most money spent? ######

# The amount of money spent is in the SPEND column.
# The dates are in the PURCHASE_ column.
# We want to add up the money, using the sum command.

tapply(myDF$SPEND, myDF$PURCHASE_, sum)

# then we sort the data and take the tail, to see the largest entries

tail(sort(tapply(myDF$SPEND, myDF$PURCHASE_, sum)))

# So the largest amount of money ($108408.41) was spent on 23 December 2017
# and the second largest amount of money ($100386.74) was spent on 23 December 2016.

###### Determine how many units were purchased at each store. ######

# The number of units is in the UNITS column.
# The stores are in the STORE_R column.
# We want to add up the number of units, using the sum command.

tapply(myDF$UNITS, myDF$STORE_R, sum)

# We see that, for instance, 4220730 units were sold at the East store.

###### Classify the products according to the amount of money spent on them.  ######
###### Which product had the most money spent on it? ######

# The amount of money spent is in the SPEND column.
# The products are in the PRODUCT_NUM column.
# We want to add up the amount of money spent, using the sum command.

tapply(myDF$SPEND, myDF$PRODUCT_NUM, sum)

# then we sort the data and take the tail, to see the largest entries

tail(sort(tapply(myDF$SPEND, myDF$PRODUCT_NUM, sum)))

# so the product 8511 had the most money spent on it: $131399.78 altogether.

#####################################################################

# We can do the same type of applications with other data sets,
# and with other functions (besides the sum function).
# For example, we can load the New York City yellow taxi cab data from June 2019.

myDF <- read.csv("/class/datamine/data/taxi/yellow/yellow_tripdata_2019-06.csv")

###### For each RatecodeID, find the average of the (total) fare of a taxi cab ride.

# The (total) fare of the ride is in the total_amount column.
# The RatecodeID is in the RatecodeID column.
# We want to take an average of the total_amount (within each RatecodeID),
# using the mean command.

tapply(myDF$total_amount, myDF$RatecodeID, mean)

# Just FYI, RatecodeID value "3" has the highest (total) fare, on average.
# This makes sense, because RatecodeID "3" rides are those rides going to Newark
# (which is outside New York City, so those rides take much longer), according to
# this pdf (which does not load in R; you need to open that pdf in your browser)
https://www1.nyc.gov/assets/tlc/downloads/pdf/data_dictionary_trip_records_yellow.pdf

###### For each PULocationID, find the average of the (total) fare of a taxi cab ride.

# The (total) fare of the ride is in the total_amount column.
# The PULocationID is in the PULocationID column.
# We want to take an average of the total_amount (within each PULocationID), using the mean command.

tapply(myDF$total_amount, myDF$PULocationID, mean)

# then we sort the data and take the tail, to see the largest entries

tail(sort(tapply(myDF$total_amount, myDF$PULocationID, mean)))

# So the most expensive location for picking up a taxi cab,
# if we consider the highest total fare (on average), is location #1,
# which is, Newark airport according to the zonelookup table.

head(read.csv("/class/datamine/data/taxi/zones/taxi+_zone_lookup.csv"))

# Try the tapply function on your own!
# Experiment with the data sets from our seminars.
# We are learning-by-doing in The Data Mine.

