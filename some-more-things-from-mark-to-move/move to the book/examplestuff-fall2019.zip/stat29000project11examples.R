# For the following examples, we will use the nycdogs dataset:
dogs <- fread("https://data.cityofnewyork.us/api/views/nu7n-tubp/rows.csv?accessType=DOWNLOAD", na.strings=c("", "datatable.na.strings","NA"))

# Obviously they've incorrectly named a column that contains Year data
setnames(dogs, "AnimalBirthMonth", "AnimalBirthYear")

# number of rows
dogs[, .N]

# number of male dogs
dogs[AnimalGender=="M", .N]

# number of male dogs born in 2010
dogs[AnimalGender=="M" & AnimalBirthYear==2010, .N]

# create a new column from other columns
dogs[,date_range:=paste(LicenseIssuedDate, " - ", LicenseExpiredDate)]

# sum the zip codes by the LicenseIssuedDate month, then sort by month
dogs[,.(sum(ZipCode)),.(month(mdy(LicenseIssuedDate)))][order(month)]

# create multiple columns at once
dat <- data.table(x=c(1,2,3), y=c(4,5,6))
dat[, c("xnorm", "ynorm"):=list( (x-min(x)) / (max(x)-min(x)),  (y-min(y)) / (max(y)-min(y)) )]

# plot of number of M and F dogs by year
ggplot(dogs[is.na(AnimalGender)==F]) +
  geom_bar(na.rm=TRUE, aes(x = AnimalGender, group=AnimalGender, col=AnimalGender, fill=AnimalGender)) +
  facet_grid(~`Extract Year`) +
  scale_x_discrete(breaks=c("M", "F"), labels = c("Male", "Female")) +
  theme(axis.text.x = element_text(angle=75, hjust = 1),
        strip.text = element_text(size = 13)) +
  labs(x = 'Gender', y = 'Count') +
  scale_color_manual(values = c('pink','lightblue'), labels = c('Female','Male')) +
  scale_fill_manual(values = c('pink','lightblue'), labels = c('Female','Male'))
