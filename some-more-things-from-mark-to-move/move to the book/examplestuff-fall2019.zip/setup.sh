#!/bin/bash

echo -en "homedir <- system('echo ~',intern=TRUE)\nrlibtop <- paste(homedir,'R',sep='/')\ncluster <- strsplit(system('hostname -s',intern=TRUE),split='-')[[1]][1]\nrinstall <- basename(Sys.getenv('R_ROOT'))\nrunique <- paste(cluster,rinstall,sep='_')\nR_LIBS_USER <- paste(rlibtop, cluster, rinstall,sep='/')\nSys.setenv(R_LIBS_USER=R_LIBS_USER)\nsystem(paste('mkdir -p ',R_LIBS_USER,sep=''))\n.libPaths(R_LIBS_USER)\nrm(cluster, homedir, rinstall, rlibtop, runique)" > ~/.Rprofile
module load r
Rscript -e 'install.packages("IRkernel", repos="https://cloud.r-project.org")'
mkdir -p ~/.local/share/jupyter/kernels/
scp -r ~glentner/public/kernels/ir-3.6-scholar ~/.local/share/jupyter/kernels/
