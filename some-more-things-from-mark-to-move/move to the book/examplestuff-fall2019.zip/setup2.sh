#!/bin/bash
mkdir -p ~/.local/share/jupyter/kernels/python3project11/
cp /class/datamine/data/spring2020/project11-env/share/jupyter/kernels/python3/kernel.json ~/.local/share/jupyter/kernels/python3project11/
