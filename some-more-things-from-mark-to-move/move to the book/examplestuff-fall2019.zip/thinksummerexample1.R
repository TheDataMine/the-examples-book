install.packages("RMariaDB")
library(RMariaDB)
connection<-dbConnect(RMariaDB::MariaDB(),
                      host="scholar-db.rcac.purdue.edu",
                      db="elections",
                      user="elections_user",
                      password="Dataelect!98")
myDF <- dbGetQuery(connection, "SELECT * FROM elections WHERE employer='PURDUE UNIVERSITY'")
head(myDF)



