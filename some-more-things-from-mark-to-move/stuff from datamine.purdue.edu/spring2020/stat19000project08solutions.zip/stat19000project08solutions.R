# 1a
# Answers may vary. Examples include:
# RMarkdown is a file format for making dynamic documents with R.
# Markdown is a text format that embeds formatting directives in plain text documents in a natural way.
# Markdown is a ‘markup’ language.
# An RMarkdown is a document written in markdown that contains chunks of embedded R code.
# RMarkdown is an extension to Markdown that allows embeded R code.
# Etc.

# 1b
# Answers may vary, but should contain two of the following: HTML, pdf, word

# 1c
# *data analysis* or _data analysis_
# **DataMine** or __DataMine__
# [article](https://google.com/)

# 2
# See stat19000project08question02solution.Rmd or stat19000project08question02solution.pdf

# 3
# Answers will vary.