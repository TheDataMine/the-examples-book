#! /usr/bin/python3.6

# import packages directly below this line
# for example, you could import the package 'os'
import sys

def main():
    if len(sys.argv) != 2:
        friend = "friend"
        
    else: 
        friend = sys.argv[1]
    

    print(

f'             .-"""-.\n'
f'           /       \\\n'
f'           \       /\n'
f'    .-"""-.-`.-.-.<  _\n'
f'   /      _,-\ ()()_/:)\n'
f'   \     / ,  `     `|     Hello {friend}!\n'
f"    '-..-| \-.,___,  /\n"
f'          \ `-.__/  /\n'
f'     jgs / `-.__.-\`\n'
f'        / /|    ___\\\n'
f'       ( ( |.-"`   `\'\\\n'
f'        \ \/    {{}}{{}}  |\n'
f'         \|           /\n'
f'          \        , /\n'
f"          ( __`;-;'__`)\n"
f"          `//'`   `||`\n"
f'         _//       ||\n'
f' .-"-._,(__)     .(__).-""-.\n'
f'/          \    /           \\\n'
f'\          /    \           /\n'
f" `'-------`      `--------'`\n"
'\n'
f'Compliments of jgs from asciiart.eu.\n'
)

if __name__ == "__main__":
    main()