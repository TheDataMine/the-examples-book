#! /usr/bin/python3.6

# import packages directly below this line
# for example, you could import the package 'os'
import argparse
import string


def squeak(word: str):
    return word.lower().translate(str.maketrans(string.ascii_lowercase, "ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖᵠʳˢᵗᵘᵛʷˣʸᶻ"))


def yell(word: str):
    return word.upper()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("friend", help="greet the friend you use here", nargs="?", default="friend")
    parser.add_argument("-v", "--volume", help="control the volume at which Mickey speaks", default=0, action="count")
    args = parser.parse_args()

    print(f'{type(args.volume)}')

    if args.volume < 2:
        args.friend = squeak(args.friend)
    if args.volume > 2:
        args.friend = yell(args.friend)

    print(

f'             .-"""-.\n'
f'           /       \\\n'
f'           \       /\n'
f'    .-"""-.-`.-.-.<  _\n'
f'   /      _,-\ ()()_/:)\n'
f'   \     / ,  `     `|     Hello {args.friend}!\n'
f"    '-..-| \-.,___,  /\n"
f'          \ `-.__/  /\n'
f'     jgs / `-.__.-\`\n'
f'        / /|    ___\\\n'
f'       ( ( |.-"`   `\'\\\n'
f'        \ \/    {{}}{{}}  |\n'
f'         \|           /\n'
f'          \        , /\n'
f"          ( __`;-;'__`)\n"
f"          `//'`   `||`\n"
f'         _//       ||\n'
f' .-"-._,(__)     .(__).-""-.\n'
f'/          \    /           \\\n'
f'\          /    \           /\n'
f" `'-------`      `--------'`\n"
'\n'
f'Compliments of jgs from asciiart.eu.\n'
)

if __name__ == "__main__":
    main()