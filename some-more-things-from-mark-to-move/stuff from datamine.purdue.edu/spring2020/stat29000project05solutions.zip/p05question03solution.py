#! /usr/bin/python3.6

# import packages below
import argparse
from sklearn.feature_selection import chi2
from media.rottentomatoes.reviews import get_reviews
from media.rottentomatoes import utilities as utils

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("rt_id", help="rotten tomato movie id")
    parser.add_argument("-c", "--count", type=int, help="control the number of reviews to utilize", default=50)
    args = parser.parse_args()

    corpus, classifications = get_reviews(args.rt_id, args.count)
    terms = utils.corpus_terms(corpus)
    tfidf_scores = utils.tfidf(corpus, terms)

    chi2scores = chi2(tfidf_scores, classifications)[0]
    chi2scores = zip(terms, chi2scores)

    print("Great words to use as features for a review classifier:")
    words = [word for word in sorted(chi2scores, key=lambda x:x[1], reverse=True)[:10]]
    for idx, word in enumerate(words, 1):
        print(f'{idx}. {word[0]} ({word[1]:.3f})')

if __name__ == "__main__":
    main()